import{a as k,A as de}from"./api-CRHtPcXj.js";import{a as pe}from"./auth-bridge-BJwpKOTo.js";const h="league-42-hover-tooltip",Q="league-42-tooltip-style";let ne=[],oe=[],G=[],A=null;function me(e,t,n=[]){ne=e,oe=t,G=n}function ue(e){const t=ne.find(r=>r.login===e),n=oe.filter(r=>r.playerALogin===e||r.playerBLogin===e),o=n.filter(r=>{const i=r.playerALogin===e;return i&&r.winner==="A"||!i&&r.winner==="B"}).length,a=n.length-o;return{login:e,imageUrl:t?.imageUrl??null,title:t?.title??null,elo:t?.elo??1e3,rank:t?.rank??null,wins:o,losses:a,trophies:t?.tournamentsWon??0,dodges:t?.dodgeCount??0}}function fe(){if(document.getElementById(Q))return;const e=document.createElement("style");e.id=Q,e.textContent=`
    #${h} {
      position: fixed;
      z-index: 2147483647;
      background: #0b0f17;
      border: 1px solid #007577;
      border-radius: 4px;
      padding: 12px;
      width: 240px;
      box-shadow: 0 6px 24px rgba(0,0,0,0.5), 0 0 16px rgba(0, 217, 220, 0.25);
      font-family: 'Inter', system-ui, sans-serif;
      color: #e6ecf5;
      font-size: 12px;
      pointer-events: auto;
      animation: l42-tip-in 120ms ease-out;
    }
    @keyframes l42-tip-in {
      from { opacity: 0; transform: translateY(-4px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    #${h} .l42tt-head {
      display: flex; align-items: center; gap: 10px;
      margin-bottom: 10px;
      padding-bottom: 10px;
      border-bottom: 1px solid #243044;
    }
    #${h} .l42tt-av {
      width: 44px; height: 44px;
      border-radius: 50%;
      background: linear-gradient(135deg, #007577, #00d9dc);
      color: #001416;
      display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 18px; text-transform: uppercase;
      border: 2px solid #00d9dc;
      box-shadow: 0 0 12px rgba(0, 217, 220, 0.4);
      overflow: hidden; flex-shrink: 0;
    }
    #${h} .l42tt-av img {
      width: 100%; height: 100%; object-fit: cover; display: block;
    }
    #${h} .l42tt-name {
      font-weight: 800; font-size: 14px;
      color: #fff; line-height: 1.2;
    }
    #${h} .l42tt-sub {
      color: #6b7689; font-size: 10px;
      text-transform: uppercase; letter-spacing: 0.1em;
      margin-top: 2px;
    }
    #${h} .l42tt-title {
      color: #ffb71b; font-size: 11px;
      font-style: italic; font-weight: 600;
      margin-top: 4px;
      text-shadow: 0 0 6px rgba(255, 183, 27, 0.4);
    }
    #${h} .l42tt-ops {
      color: #ff3b5c; font-size: 11px;
      font-weight: 700;
      margin-top: 4px;
      letter-spacing: 0.04em;
      text-shadow: 0 0 6px rgba(255, 59, 92, 0.4);
    }
    #${h} .l42tt-stats {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
    }
    #${h} .l42tt-stat {
      background: #111827;
      border: 1px solid #243044;
      border-radius: 3px;
      padding: 8px;
      text-align: center;
    }
    #${h} .l42tt-stat-v {
      font-size: 18px; font-weight: 800;
      font-variant-numeric: tabular-nums;
      line-height: 1;
    }
    #${h} .l42tt-stat-l {
      font-size: 9px; color: #95a3b8;
      text-transform: uppercase; letter-spacing: 0.1em;
      margin-top: 4px; font-weight: 600;
    }
    #${h} .v-elo   { color: #00d9dc; }
    #${h} .v-trophy{ color: #ffb71b; }
    #${h} .v-win   { color: #ffb71b; }
    #${h} .v-loss  { color: #ff3b5c; }
  `,document.head.appendChild(e)}function ge(){let e=document.getElementById(h);return e||(e=document.createElement("div"),e.id=h,e.addEventListener("mouseenter",()=>{A&&clearTimeout(A)}),e.addEventListener("mouseleave",ae),document.body.appendChild(e),e)}function be(e,t){e.innerHTML="";const n=document.createElement("div");n.className="l42tt-head";const o=document.createElement("div");if(o.className="l42tt-av",t.imageUrl){const l=document.createElement("img");l.src=t.imageUrl,l.alt=t.login,l.onerror=()=>{o.innerHTML="",o.textContent=(t.login[0]??"?").toUpperCase()},o.appendChild(l)}else o.textContent=(t.login[0]??"?").toUpperCase();const a=document.createElement("div"),r=document.createElement("div");r.className="l42tt-name",r.textContent=t.login;const i=document.createElement("div");if(i.className="l42tt-sub",i.textContent=t.rank!=null?`42 League · #${t.rank}`:"42 League · non classé",a.append(r,i),t.title){const l=document.createElement("div");l.className="l42tt-title",l.textContent=`« ${t.title} »`,a.append(l)}const d=G.find(l=>l.targetLogin===t.login),c=G.find(l=>l.ownerLogin===t.login);if(d){const l=document.createElement("div");l.className="l42tt-ops",l.textContent=`☠ Ops de ${d.ownerLogin}`,a.append(l)}if(c){const l=document.createElement("div");l.className="l42tt-ops",l.textContent=`☠ Traque ${c.targetLogin}`,a.append(l)}n.append(o,a);const m=document.createElement("div");m.className="l42tt-stats",m.append(D(String(t.elo),"ELO","v-elo"),D(String(t.trophies),"Tournois","v-trophy"),D(String(t.wins),"Wins","v-win"),D(String(t.losses),"Losses","v-loss")),e.append(n,m)}function D(e,t,n){const o=document.createElement("div");o.className="l42tt-stat";const a=document.createElement("div");a.className=`l42tt-stat-v ${n}`,a.textContent=e;const r=document.createElement("div");return r.className="l42tt-stat-l",r.textContent=t,o.append(a,r),o}function xe(e,t){const n=t.getBoundingClientRect(),o=240,a=e.offsetHeight||160;let r=n.left,i=n.top-a-6;i<8&&(i=n.bottom+6),r+o>window.innerWidth-8&&(r=window.innerWidth-o-8),r<8&&(r=8),i+a>window.innerHeight-8&&(i=window.innerHeight-a-8),e.style.left=`${r}px`,e.style.top=`${i}px`}function he(e,t){fe();const n=ge();n.style.display="block",be(n,ue(t)),requestAnimationFrame(()=>xe(n,e))}function ae(){A&&clearTimeout(A),A=setTimeout(()=>{const e=document.getElementById(h);e&&(e.style.display="none")},150)}function ye(e,t){e.addEventListener("mouseenter",()=>{A&&clearTimeout(A),he(e,t)}),e.addEventListener("mouseleave",ae)}const $="league-42-confirm-host",Z="league-42-confirm-style";function ve(){if(document.getElementById(Z))return;const e=document.createElement("style");e.id=Z,e.textContent=`
    #${$} {
      position: fixed; inset: 0;
      z-index: 2147483647;
      display: flex; align-items: center; justify-content: center;
      background: rgba(0,0,0,0.55);
      backdrop-filter: blur(4px);
      animation: l42cf-in 120ms ease-out;
      font-family: 'Inter', system-ui, sans-serif;
    }
    @keyframes l42cf-in { from { opacity: 0 } to { opacity: 1 } }
    @keyframes l42cf-pop { from { transform: scale(0.92); opacity: 0 } to { transform: scale(1); opacity: 1 } }
    #${$} .l42cf-card {
      background: #0b0f17;
      color: #e6ecf5;
      border: 1px solid #243044;
      border-radius: 4px;
      padding: 22px 22px 18px;
      width: 380px; max-width: calc(100vw - 32px);
      box-shadow: 0 18px 48px rgba(0,0,0,0.5), 0 0 32px rgba(0, 217, 220, 0.18);
      animation: l42cf-pop 160ms ease-out;
    }
    #${$} .l42cf-title {
      font-size: 13px; font-weight: 800;
      text-transform: uppercase; letter-spacing: 0.18em;
      color: #00d9dc;
      margin-bottom: 12px;
    }
    #${$} .l42cf-msg { font-size: 13px; line-height: 1.5; color: #e6ecf5; }
    #${$} .l42cf-warn {
      margin-top: 12px;
      background: rgba(255, 59, 92, 0.08);
      border: 1px solid rgba(255, 59, 92, 0.45);
      color: #ff8095;
      padding: 10px 12px;
      border-radius: 3px;
      font-size: 12px; font-weight: 500;
      line-height: 1.4;
    }
    #${$} .l42cf-actions {
      display: flex; gap: 10px; justify-content: flex-end;
      margin-top: 18px;
    }
    #${$} button {
      font-family: inherit; font-size: 11px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.08em;
      padding: 9px 18px; border-radius: 3px; cursor: pointer;
      border: none; transition: filter 120ms, transform 80ms, box-shadow 120ms;
    }
    #${$} button.l42cf-cancel {
      background: transparent; color: #95a3b8;
      border: 1px solid #243044;
    }
    #${$} button.l42cf-cancel:hover {
      color: #fff; border-color: #6b7689;
    }
    #${$} button.l42cf-ok {
      background: linear-gradient(180deg, #00d9dc, #00babc);
      color: #001416;
    }
    #${$} button.l42cf-ok:hover { filter: brightness(1.1); box-shadow: 0 0 12px rgba(0, 217, 220, 0.35); }
    #${$} button.l42cf-ok.l42cf-danger {
      background: linear-gradient(180deg, #ff3b5c, #c8203f);
      color: #fff;
    }
    #${$} button.l42cf-ok.l42cf-danger:hover { box-shadow: 0 0 14px rgba(255, 59, 92, 0.5); }
  `,document.head.appendChild(e)}function Ee(e){return ve(),new Promise(t=>{const n=document.createElement("div");n.id=$;const o=document.createElement("div");o.className="l42cf-card";const a=document.createElement("div");a.className="l42cf-title",a.textContent=e.title;const r=document.createElement("div");if(r.className="l42cf-msg",r.textContent=e.message,o.append(a,r),e.warning){const u=document.createElement("div");u.className="l42cf-warn",u.textContent=e.warning,o.append(u)}const i=document.createElement("div");i.className="l42cf-actions";const d=document.createElement("button");d.className="l42cf-cancel",d.textContent=e.cancelLabel??"Annuler";const c=document.createElement("button");c.className="l42cf-ok l42cf-danger",c.textContent=e.confirmLabel??"Confirmer";const m=u=>{document.removeEventListener("keydown",l),n.remove(),t(u)},l=u=>{u.key==="Escape"?m(!1):u.key==="Enter"&&m(!0)};d.onclick=()=>m(!1),c.onclick=()=>m(!0),n.onclick=u=>{u.target===n&&m(!1)},document.addEventListener("keydown",l),i.append(d,c),o.append(i),n.append(o),document.body.append(n),setTimeout(()=>c.focus(),0)})}const s="league-42-pending-block",J="league-42-pending-style",g="league-42-notif-banner",V="league-42-notif-style",$e=3e4,we=["évaluations","evaluations"],re="https://42league.fr";let L=null,X=[],H=[],_=[],U=[],q=null;const x=new Set,F=new Set,j=new Map;function S(e,t="error"){const n="league-42-toast";document.getElementById(n)?.remove();const o=document.createElement("div");o.id=n,o.textContent=e,o.style.cssText=`
    position: fixed; top: 16px; right: 16px;
    z-index: 2147483647;
    background: ${t==="ok"?"#e6f9fa":"#fbeaec"};
    color: ${t==="ok"?"#00a3a5":"#b00020"};
    border: 1px solid ${t==="ok"?"#00babc":"#b00020"};
    padding: 10px 14px; border-radius: 4px;
    font-family: system-ui, sans-serif; font-size: 13px;
    font-weight: 600;
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    max-width: 340px;
    animation: l42-toast-in 200ms ease-out;
  `,document.body.appendChild(o),setTimeout(()=>o.remove(),5e3)}function B(e){return(e instanceof Error?e.message:String(e)).includes("Extension context invalidated")}function M(){q&&clearInterval(q),q=null,document.getElementById(s)?.remove(),document.getElementById(J)?.remove(),document.getElementById(g)?.remove(),document.getElementById(V)?.remove()}function ke(){if(document.getElementById(V))return;const e=document.createElement("style");e.id=V,e.textContent=`
    @keyframes l42nb-in {
      from { opacity: 0; transform: translateY(-8px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes l42nb-pulse {
      0%, 100% { box-shadow: 0 0 0 0 rgba(255, 183, 27, 0.4); }
      50%       { box-shadow: 0 0 0 6px rgba(255, 183, 27, 0); }
    }
    #${g} {
      position: fixed;
      top: 16px; right: 16px;
      z-index: 2147483646;
      width: 320px;
      background: #0b0f17;
      border: 1px solid rgba(255, 183, 27, 0.5);
      border-radius: 8px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 24px rgba(255,183,27,0.15);
      font-family: 'Inter', system-ui, sans-serif;
      animation: l42nb-in 220ms ease-out, l42nb-pulse 2s ease-in-out 500ms 3;
      overflow: hidden;
    }
    #${g} .l42nb-header {
      display: flex; align-items: center; gap: 8px;
      padding: 10px 12px 8px;
      border-bottom: 1px solid rgba(255,183,27,0.2);
    }
    #${g} .l42nb-icon { font-size: 14px; }
    #${g} .l42nb-title {
      flex: 1;
      font-size: 10px; font-weight: 800;
      text-transform: uppercase; letter-spacing: 0.15em;
      color: #ffb71b;
    }
    #${g} .l42nb-close {
      background: none; border: none; cursor: pointer;
      color: #6b7689; font-size: 16px; line-height: 1;
      width: 20px; height: 20px;
      display: flex; align-items: center; justify-content: center;
      border-radius: 3px;
      transition: color 120ms, background 120ms;
    }
    #${g} .l42nb-close:hover { color: #e6ecf5; background: rgba(255,255,255,0.08); }
    #${g} .l42nb-match {
      padding: 10px 12px;
      border-bottom: 1px solid rgba(255,255,255,0.06);
    }
    #${g} .l42nb-match:last-child { border-bottom: none; }
    #${g} .l42nb-meta {
      display: flex; align-items: center; gap: 6px;
      margin-bottom: 8px;
      font-size: 12px; color: #95a3b8;
    }
    #${g} .l42nb-declarer {
      color: #ffb71b; font-weight: 700;
    }
    #${g} .l42nb-score {
      font-weight: 800; font-variant-numeric: tabular-nums;
      font-size: 18px; color: #ffffff;
      letter-spacing: 0.05em;
    }
    #${g} .l42nb-score-sep { color: #6b7689; margin: 0 4px; font-size: 16px; }
    #${g} .l42nb-hint {
      font-size: 10px; color: #6b7689;
    }
    #${g} .l42nb-actions {
      display: flex; gap: 6px; margin-top: 8px;
    }
    #${g} .l42nb-btn-confirm {
      flex: 1; padding: 7px 12px;
      background: linear-gradient(180deg, #00d9dc, #00babc);
      color: #001416; font-weight: 800;
      font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em;
      border: none; border-radius: 5px; cursor: pointer;
      transition: filter 120ms, transform 80ms;
    }
    #${g} .l42nb-btn-confirm:hover { filter: brightness(1.1); }
    #${g} .l42nb-btn-confirm:active { transform: scale(0.97); }
    #${g} .l42nb-btn-confirm:disabled { opacity: 0.4; cursor: default; }
    #${g} .l42nb-btn-contest {
      padding: 7px 12px;
      background: transparent;
      color: #95a3b8; font-weight: 700;
      font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em;
      border: 1px solid #243044; border-radius: 5px; cursor: pointer;
      transition: color 120ms, border-color 120ms, background 120ms;
    }
    #${g} .l42nb-btn-contest:hover {
      color: #ff3b5c; border-color: rgba(255,59,92,0.5);
      background: rgba(255,59,92,0.06);
    }
    #${g} .l42nb-btn-contest:disabled { opacity: 0.4; cursor: default; }
  `,document.head.appendChild(e)}function Ce(){const e=H.filter(i=>i.opponentLogin===L);if(e.length===0){document.getElementById(g)?.remove();return}ke(),document.getElementById(g)?.remove();const t=document.createElement("div");t.id=g;const n=document.createElement("div");n.className="l42nb-header";const o=document.createElement("span");o.className="l42nb-icon",o.textContent="⚡";const a=document.createElement("span");a.className="l42nb-title",a.textContent=`${e.length} game${e.length>1?"s":""} à confirmer`;const r=document.createElement("button");r.className="l42nb-close",r.textContent="×",r.title="Fermer (réapparaît au prochain refresh)",r.onclick=()=>t.remove(),n.append(o,a,r),t.append(n);for(const i of e){const d=document.createElement("div");d.className="l42nb-match";const c=document.createElement("div");c.className="l42nb-meta";const m=document.createElement("span");m.className="l42nb-declarer",m.textContent=i.declarerLogin,c.append(m,document.createTextNode(" a déclaré :"));const l=document.createElement("div");l.style.cssText="display:flex;align-items:baseline;gap:0;margin:2px 0;";const u=document.createElement("span");u.className="l42nb-score";const y=document.createElement("span");y.className="l42nb-score-sep",y.textContent="–";const v=document.createElement("span");v.textContent=String(i.scoreDeclarer);const p=document.createElement("span");p.textContent=String(i.scoreOpponent),u.append(v,y,p);const w=document.createElement("span");w.className="l42nb-hint",w.textContent="(eux – toi)",l.append(u,w),l.style.cssText="display:flex;align-items:baseline;gap:8px;margin:4px 0;";const N=document.createElement("div");N.className="l42nb-actions";const E=document.createElement("button");E.className="l42nb-btn-confirm",E.textContent="✓ Confirmer",E.disabled=x.has(i.id),E.onclick=async()=>{E.disabled=!0,b.disabled=!0,x.add(i.id);try{await k.confirmMatch(i.id,i.scoreOpponent,i.scoreDeclarer),S("Match confirmé ✓","ok"),j.delete(i.id)}catch(T){if(B(T))return M();const C=T instanceof Error?T.message:String(T);C.includes("409")||C.toLowerCase().includes("différents")?(j.delete(i.id),S("Scores différents · match annulé, à redéclarer")):S("Erreur de validation")}finally{x.delete(i.id),z()}};const b=document.createElement("button");b.className="l42nb-btn-contest",b.textContent="Contester",b.disabled=x.has(i.id),b.onclick=()=>ie(i),N.append(E,b),d.append(c,l,N),t.append(d)}document.body.append(t)}const f="league-42-contest-host",ee="league-42-contest-style";function Le(){if(document.getElementById(ee))return;const e=document.createElement("style");e.id=ee,e.textContent=`
    @keyframes l42ct-in  { from { opacity: 0 } to { opacity: 1 } }
    @keyframes l42ct-pop { from { transform: scale(0.92); opacity: 0 } to { transform: scale(1); opacity: 1 } }
    #${f} {
      position: fixed; inset: 0;
      z-index: 2147483647;
      display: flex; align-items: center; justify-content: center;
      background: rgba(0,0,0,0.65);
      backdrop-filter: blur(6px);
      animation: l42ct-in 150ms ease-out;
      font-family: 'Inter', system-ui, sans-serif;
      padding: 16px;
    }
    #${f} .l42ct-card {
      background: #0b0f17;
      border: 1px solid rgba(255,59,92,0.35);
      border-radius: 10px;
      padding: 20px 20px 18px;
      width: 400px; max-width: calc(100vw - 32px);
      box-shadow: 0 20px 60px rgba(0,0,0,0.6), 0 0 40px rgba(255,59,92,0.1);
      animation: l42ct-pop 180ms ease-out;
    }
    #${f} .l42ct-header {
      display: flex; align-items: flex-start; justify-content: space-between;
      margin-bottom: 14px;
    }
    #${f} .l42ct-title {
      font-size: 10px; font-weight: 800;
      text-transform: uppercase; letter-spacing: 0.18em;
      color: #ff3b5c; margin-bottom: 3px;
    }
    #${f} .l42ct-sub {
      font-size: 11px; color: #6b7689;
    }
    #${f} .l42ct-close {
      background: none; border: none; cursor: pointer;
      color: #6b7689; font-size: 18px; line-height: 1;
      width: 24px; height: 24px;
      display: flex; align-items: center; justify-content: center;
      border-radius: 4px; transition: color 120ms, background 120ms;
    }
    #${f} .l42ct-close:hover { color: #e6ecf5; background: rgba(255,255,255,0.08); }
    #${f} .l42ct-warn {
      background: rgba(255,59,92,0.07);
      border: 1px solid rgba(255,59,92,0.25);
      color: #ff8095; border-radius: 6px;
      padding: 8px 10px; font-size: 11px; line-height: 1.4;
      margin-bottom: 14px;
    }
    #${f} .l42ct-label {
      font-size: 9px; font-weight: 800;
      text-transform: uppercase; letter-spacing: 0.12em;
      color: #6b7689; margin-bottom: 6px;
    }
    #${f} .l42ct-reasons {
      display: grid; grid-template-columns: 1fr 1fr; gap: 6px;
      margin-bottom: 12px;
    }
    #${f} .l42ct-reason {
      padding: 10px 10px 8px;
      background: #111827; border: 1px solid #243044;
      border-radius: 6px; cursor: pointer; text-align: left;
      transition: border-color 120ms, background 120ms;
    }
    #${f} .l42ct-reason:hover { border-color: rgba(255,59,92,0.4); background: rgba(255,59,92,0.04); }
    #${f} .l42ct-reason.l42ct-selected {
      border-color: rgba(255,59,92,0.6); background: rgba(255,59,92,0.08);
    }
    #${f} .l42ct-reason-icon { font-size: 16px; margin-bottom: 4px; display: block; }
    #${f} .l42ct-reason-text {
      font-size: 11px; font-weight: 600; color: #e6ecf5; line-height: 1.3;
    }
    #${f} .l42ct-textarea {
      width: 100%; box-sizing: border-box;
      padding: 9px 10px;
      background: #0b0f17; border: 1px solid #243044;
      border-radius: 6px; resize: none;
      font-family: inherit; font-size: 12px; color: #e6ecf5;
      line-height: 1.5; outline: none;
      transition: border-color 120ms;
    }
    #${f} .l42ct-textarea:focus { border-color: rgba(255,59,92,0.5); }
    #${f} .l42ct-counter {
      text-align: right; font-size: 10px; color: #6b7689;
      margin-top: 4px; margin-bottom: 14px;
    }
    #${f} .l42ct-actions {
      display: flex; gap: 8px; justify-content: flex-end;
    }
    #${f} .l42ct-cancel {
      padding: 8px 16px;
      background: transparent; border: 1px solid #243044;
      color: #95a3b8; border-radius: 5px; cursor: pointer;
      font-family: inherit; font-size: 11px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.08em;
      transition: color 120ms, border-color 120ms;
    }
    #${f} .l42ct-cancel:hover { color: #fff; border-color: #6b7689; }
    #${f} .l42ct-submit {
      padding: 8px 18px;
      background: linear-gradient(180deg, #ff3b5c, #c8203f);
      color: #fff; border: none; border-radius: 5px; cursor: pointer;
      font-family: inherit; font-size: 11px; font-weight: 800;
      text-transform: uppercase; letter-spacing: 0.08em;
      transition: filter 120ms, box-shadow 120ms;
    }
    #${f} .l42ct-submit:hover:not(:disabled) {
      filter: brightness(1.1);
      box-shadow: 0 0 14px rgba(255,59,92,0.5);
    }
    #${f} .l42ct-submit:disabled { opacity: 0.35; cursor: default; }
  `,document.head.appendChild(e)}function ie(e){Le(),document.getElementById(f)?.remove();let t=null;const n=document.createElement("div");n.id=f;const o=document.createElement("div");o.className="l42ct-card";const a=document.createElement("div");a.className="l42ct-header";const r=document.createElement("div"),i=document.createElement("div");i.className="l42ct-title",i.textContent="Contester ce score";const d=document.createElement("div");d.className="l42ct-sub",d.innerHTML=`<strong style="color:#e6ecf5">${e.declarerLogin}</strong> a déclaré <strong style="color:#e6ecf5">${e.scoreDeclarer}–${e.scoreOpponent}</strong>`,r.append(i,d);const c=document.createElement("button");c.className="l42ct-close",c.textContent="×",c.onclick=()=>n.remove(),a.append(r,c);const m=document.createElement("div");m.className="l42ct-warn",m.innerHTML="⚠ Ce système est basé sur la <strong>confiance</strong>. Une contestation injustifiée nuit à la communauté.";const l=document.createElement("div");l.className="l42ct-label",l.textContent="Motif";const u=document.createElement("div");u.className="l42ct-reasons";const y=(C,P,ce)=>{const R=document.createElement("button");R.className="l42ct-reason",R.dataset.value=C;const W=document.createElement("span");W.className="l42ct-reason-icon",W.textContent=P;const Y=document.createElement("span");return Y.className="l42ct-reason-text",Y.textContent=ce,R.append(W,Y),R.onclick=()=>{u.querySelectorAll(".l42ct-reason").forEach(se=>se.classList.remove("l42ct-selected")),R.classList.add("l42ct-selected"),t=C,T()},R};u.append(y("never_played","🚫","La game n'a jamais eu lieu"),y("wrong_score","❌","Le score est incorrect"));const v=document.createElement("div");v.className="l42ct-label",v.textContent="Explique-toi *";const p=document.createElement("textarea");p.className="l42ct-textarea",p.rows=3,p.placeholder="Décris ce qui s'est passé (min. 10 caractères)…";const w=document.createElement("div");w.className="l42ct-counter",w.textContent="0 / 500",p.oninput=()=>{p.value.length>500&&(p.value=p.value.slice(0,500)),w.textContent=`${p.value.length} / 500`,T()};const N=document.createElement("div");N.className="l42ct-actions";const E=document.createElement("button");E.className="l42ct-cancel",E.textContent="Annuler",E.onclick=()=>n.remove();const b=document.createElement("button");b.className="l42ct-submit",b.textContent="Envoyer la contestation",b.disabled=!0,N.append(E,b);const T=()=>{b.disabled=!t||p.value.trim().length<10};b.onclick=async()=>{if(!(!t||p.value.trim().length<10)){b.disabled=!0,E.disabled=!0,x.add(e.id);try{await k.rejectMatch(e.id,t,p.value.trim()),n.remove(),S("Contestation envoyée","ok")}catch(C){if(B(C))return M();S("Erreur lors de la contestation")}finally{x.delete(e.id),z()}}},n.onclick=C=>{C.target===n&&n.remove()},document.addEventListener("keydown",function C(P){P.key==="Escape"&&(n.remove(),document.removeEventListener("keydown",C))}),o.append(a,m,l,u,v,p,w,N),n.append(o),document.body.append(n),setTimeout(()=>p.focus(),50)}function Ne(){if(document.getElementById(J))return;const e=document.createElement("style");e.id=J,e.textContent=`
    #${s} {
      display: flex; flex-direction: column;
      padding: 0;
      margin: 0 0 6px 0;
    }
    #${s}:not(:empty) {
      border-bottom: 1px solid #e8e8e8;
      padding-bottom: 4px;
      margin-bottom: 6px;
    }
    #${s} .l42-line {
      display: flex; align-items: center; gap: 5px;
      font: inherit; font-size: 12px; line-height: 1.4;
      font-weight: 400;
      padding: 3px 4px;
      color: #555;
      flex-wrap: wrap;
    }
    #${s} .l42-emoji { font-size: 12px; }
    #${s} .l42-text { color: #555; }
    #${s} .l42-badge {
      font-size: 9px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.08em;
      padding: 2px 6px; border-radius: 2px;
      margin-right: 4px;
    }
    #${s} .l42-badge.l42-bg-pending {
      background: rgba(255, 183, 27, 0.15); color: #b8860b;
      border: 1px solid rgba(184, 134, 11, 0.4);
    }
    #${s} .l42-badge.l42-bg-accepted {
      background: rgba(0, 186, 188, 0.12); color: #00a3a5;
      border: 1px solid rgba(0, 163, 165, 0.4);
    }
    #${s} .l42-badge.l42-bg-confirm {
      background: rgba(176, 0, 32, 0.08); color: #b00020;
      border: 1px solid rgba(176, 0, 32, 0.3);
    }
    #${s} .l42-badge.l42-bg-played {
      background: rgba(120, 120, 120, 0.1); color: #666;
      border: 1px solid rgba(120, 120, 120, 0.3);
    }
    #${s} .l42-opp {
      color: #00babc; text-decoration: none; font-weight: 500;
    }
    #${s} .l42-opp:hover { text-decoration: underline; color: #00a3a5; }
    #${s} .l42-score {
      font-variant-numeric: tabular-nums;
      font-size: 11px; font-weight: 600;
      display: inline-flex; align-items: baseline;
    }
    #${s} .l42-w { color: #c9a227; }
    #${s} .l42-l { color: #b00020; }
    #${s} .l42-suffix { font-size: 9px; margin-left: 1px; }
    #${s} .l42-dash { color: #bbb; margin: 0 4px; font-size: 11px; }
    #${s} .l42-when {
      color: #888; font-size: 11px; font-style: italic;
    }
    #${s} .l42-when.l42-late { color: #b00020; font-style: normal; font-weight: 500; }
    #${s} .l42-actions { margin-left: auto; display: inline-flex; gap: 2px; align-items: center; }
    #${s} .l42-btn {
      cursor: pointer; border: none; background: transparent;
      width: 20px; height: 20px;
      display: inline-flex; align-items: center; justify-content: center;
      border-radius: 3px;
      transition: background 120ms, transform 80ms;
    }
    #${s} .l42-btn i { font-size: 12px; line-height: 1; }
    #${s} .l42-btn:disabled { opacity: 0.4; cursor: default; }
    #${s} .l42-btn:active:not(:disabled) { transform: scale(0.9); }
    #${s} .l42-ok { color: #00babc; }
    #${s} .l42-ok:hover:not(:disabled) { background: #e6f9fa; color: #00a3a5; }
    #${s} .l42-no { color: #b00020; }
    #${s} .l42-no:hover:not(:disabled) { background: #fbeaec; }
    #${s} .l42-wait { color: #999; font-size: 11px; font-style: italic; }
    #${s} .l42-cta {
      cursor: pointer; border: 1px solid #00babc; background: transparent;
      color: #00babc; font-size: 11px; font-weight: 600;
      padding: 2px 8px; border-radius: 3px;
      transition: background 120ms, color 120ms;
    }
    #${s} .l42-cta:hover { background: #00babc; color: #fff; }
    #${s} .l42-cta:disabled { opacity: 0.4; cursor: default; }
    #${s} .l42-record {
      display: flex; align-items: stretch; gap: 6px;
      flex-basis: 100%;
      margin-top: 4px;
      padding: 0;
      background: transparent;
    }
    #${s} .l42-record input {
      flex: 1;
      min-width: 0;
      padding: 8px 10px; font-size: 13px; font-weight: 600;
      border: 1px solid #d8d8d8; border-radius: 3px;
      text-align: center; font-variant-numeric: tabular-nums;
      background: transparent;
      color: inherit;
    }
    #${s} .l42-record input:focus { outline: none; border-color: #00babc; box-shadow: 0 0 0 2px rgba(0,186,188,0.15); }
    #${s} .l42-record .l42-mini {
      display: flex; align-items: center; justify-content: center;
      color: #aaa; font-size: 14px; font-weight: 600;
      padding: 0 2px;
    }
    #${s} .l42-record .l42-cta {
      padding: 6px 14px; font-size: 12px;
    }
    #${s} .l42-record .l42-btn {
      width: 30px; height: auto;
    }
  `,document.head.appendChild(e)}function Se(){const e=document.getElementById("collapseEvaluations");if(e)return e;const t=Array.from(document.querySelectorAll("h1, h2, h3, h4, .profile-title"));for(const n of t){const o=(n.textContent??"").trim().toLowerCase();if(o&&we.some(a=>o.includes(a))){const a=n.closest(".container-inner-item, .boxed, section, article");return a?a.querySelector(".overflowable-item")??a:n.parentElement}}return null}function ze(){let e=document.getElementById(s);if(e&&e.isConnected)return e;const t=Se();return t?(e||(e=document.createElement("div"),e.id=s),t.prepend(e),e):null}function Ie(e){return`https://profile.intra.42.fr/users/${encodeURIComponent(e)}`}function te(e,t){const n=document.createElement("span");n.className="l42-score "+(t?"l42-w":"l42-l");const o=document.createElement("span");o.textContent=String(e);const a=document.createElement("span");return a.className="l42-suffix",a.textContent=t?"W":"L",n.append(o,a),n}function Te(e){const t=new Date(e).getTime()-Date.now(),n=Math.round(Math.abs(t)/6e4);if(t>=0){if(n<1)return{text:"maintenant",late:!1};if(n===1)return{text:"dans 1 minute",late:!1};if(n<60)return{text:`dans ${n} minutes`,late:!1};const a=Math.floor(n/60);return{text:a===1?"dans 1 heure":`dans ${a} heures`,late:!1}}if(n<1)return{text:"à l'instant",late:!1};if(n===1)return{text:"il y a 1 minute",late:!0};if(n<60)return{text:`il y a ${n} minutes`,late:!0};const o=Math.floor(n/60);return{text:o===1?"il y a 1 heure":`il y a ${o} heures`,late:!0}}function O(e){const t=document.createElement("button");t.className=`l42-btn ${e.cls}`,t.title=e.title,t.disabled=!!e.disabled,t.onclick=e.onClick;const n=document.createElement("i");return n.className=`fal ${e.icon}`,t.appendChild(n),t}function le(e){const t=document.createElement("div");t.className="l42-line";const n=document.createElement("span");if(n.className="l42-emoji",n.textContent=e.emoji,t.append(n),e.badge){const r=document.createElement("span");r.className=`l42-badge ${e.badge.cls}`,r.textContent=e.badge.label,t.append(r)}const o=document.createElement("span");o.className="l42-text",o.textContent=e.text;const a=document.createElement("a");return a.className="l42-opp",a.href=Ie(e.opponent),a.target="_blank",a.rel="noreferrer noopener",a.textContent=e.opponent,a.dataset.login=e.opponent,ye(a,e.opponent),t.append(o,a),t}function Ae(e,t,n){const o=document.createElement("span");o.className="l42-dash",o.textContent="–",e.append(te(t,!0),o,te(n,!1))}function Be(e,t){const n=document.createElement("span"),o=Te(t);n.className="l42-when"+(o.late?" l42-late":""),n.textContent=o.text,e.append(n)}function Me(e){const t=e.opponentLogin===L,n=t?e.challengerLogin:e.opponentLogin,o=e.status==="pending"?t?"Défi reçu de":"Défi envoyé à":"Match planifié vs",a=e.status==="pending"?{label:"À ACCEPTER",cls:"l42-bg-pending"}:{label:"ACCEPTÉ · À JOUER",cls:"l42-bg-accepted"},r=le({emoji:"⚔️",text:o,opponent:n,badge:a});Be(r,e.scheduledAt);const i=document.createElement("span");if(i.className="l42-actions",e.status==="pending"&&t)i.append(O({cls:"l42-ok",title:"Accepter ce défi",icon:"fa-check",disabled:x.has(e.id),onClick:()=>_e(e)}),O({cls:"l42-no",title:"Refuser ce défi",icon:"fa-times",disabled:x.has(e.id),onClick:()=>K(e)}));else if(e.status==="pending"){const d=document.createElement("span");d.className="l42-wait",d.textContent="en attente",i.append(d,O({cls:"l42-no",title:"Annuler ce défi",icon:"fa-times",disabled:x.has(e.id),onClick:()=>K(e)}))}else if(e.status==="accepted"){if(F.has(e.id))return r.append(Re(e)),r;i.append((()=>{const d=document.createElement("button");return d.className="l42-cta",d.textContent="Saisir le score",d.disabled=x.has(e.id),d.onclick=()=>{F.add(e.id),I()},d})(),O({cls:"l42-no",title:"Annuler ce match",icon:"fa-times",disabled:x.has(e.id),onClick:()=>K(e)}))}return r.append(i),r}function Re(e){const t=document.createElement("span");t.className="l42-record";const o=e.opponentLogin===L?e.challengerLogin:e.opponentLogin,a=document.createElement("input");a.type="number",a.min="0",a.max="10",a.placeholder="Ton score";const r=document.createElement("span");r.className="l42-mini",r.textContent="–";const i=document.createElement("input");i.type="number",i.min="0",i.max="10",i.placeholder=`Score ${o}`;const d=document.createElement("button");d.className="l42-cta",d.textContent="Envoyer",d.disabled=x.has(e.id),d.onclick=async()=>{const l=Number(a.value),u=Number(i.value);!Number.isFinite(l)||!Number.isFinite(u)||await Ue(e,l,u)};const c=document.createElement("button");c.className="l42-btn l42-no",c.title="Annuler la saisie";const m=document.createElement("i");return m.className="fal fa-times",c.appendChild(m),c.onclick=()=>{F.delete(e.id),I()},t.append(a,r,i,d,c),t}function je(e){const t=e.opponentLogin===L,n=t?e.declarerLogin:e.opponentLogin,o=le({emoji:"⚔️",text:t?`Score à confirmer (déclaré par ${n})`:"Score envoyé, en attente de",opponent:n,badge:{label:"SCORE À CONFIRMER",cls:"l42-bg-confirm"}});if(!t){const y=Math.max(e.scoreDeclarer,e.scoreOpponent),v=Math.min(e.scoreDeclarer,e.scoreOpponent);Ae(o,y,v);const p=document.createElement("span");return p.className="l42-wait",p.style.cssText="margin-left: auto;",p.textContent="en attente adversaire",o.append(p),o.dataset.id=e.id,o}const a=j.get(e.id)??(()=>{const y={mine:String(e.scoreOpponent),opp:String(e.scoreDeclarer)};return j.set(e.id,y),y})(),r=document.createElement("span");r.className="l42-record";const i=document.createElement("input");i.type="number",i.min="0",i.max="10",i.placeholder="Ton score",i.value=a.mine,i.oninput=()=>{a.mine=i.value};const d=document.createElement("span");d.className="l42-mini",d.textContent="–";const c=document.createElement("input");c.type="number",c.min="0",c.max="10",c.placeholder=`Score ${n}`,c.value=a.opp,c.oninput=()=>{a.opp=c.value};const m=document.createElement("button");m.className="l42-cta",m.textContent="Valider",m.disabled=x.has(e.id),m.onclick=()=>De(e,Number(a.mine),Number(a.opp));const l=document.createElement("button");l.className="l42-btn l42-no",l.title="Refuser ce score",l.disabled=x.has(e.id),l.onclick=()=>Oe(e);const u=document.createElement("i");return u.className="fal fa-times",l.appendChild(u),r.append(i,d,c,m,l),o.append(r),o.dataset.id=e.id,o}function I(){Ne();const e=ze();if(e){e.innerHTML="";for(const t of X)e.appendChild(Me(t));for(const t of H)e.appendChild(je(t));Ce()}}async function De(e,t,n){if(!Number.isFinite(t)||!Number.isFinite(n)){S("Score invalide");return}x.add(e.id),I();try{await k.confirmMatch(e.id,t,n),j.delete(e.id),S("Match validé","ok")}catch(o){if(B(o))return M();const a=o instanceof Error?o.message:String(o);a.includes("409")||a.toLowerCase().includes("différents")?(j.delete(e.id),S("Scores différents · match annulé, à redéclarer")):(console.warn("[42 League] confirm failed",o),S("Erreur de validation"))}finally{x.delete(e.id),z()}}async function Oe(e){ie(e)}async function _e(e){x.add(e.id),I();try{await k.acceptChallenge(e.id)}catch(t){if(B(t))return M();console.warn("[42 League] accept failed",t)}finally{x.delete(e.id),z()}}async function K(e){const t=e.challengerLogin===L,n=t?e.opponentLogin:e.challengerLogin,o=e.status==="accepted";if(await Ee({title:o?"Fuir ce match ?":t?"Annuler ce défi ?":"Refuser ce défi ?",message:o?`Le match contre ${n} était accepté par les deux. Si tu annules maintenant, c'est considéré comme une fuite.`:t?`Annuler ton défi envoyé à ${n} ?`:`Refuser le défi de ${n} ?`,warning:o?"⚠ Pénalité : -10 ELO + 1 fuite marquée sur ton profil.":void 0,confirmLabel:o?"Confirmer la fuite":t?"Annuler":"Refuser",cancelLabel:"Garder"})){x.add(e.id),I();try{await k.declineChallenge(e.id)}catch(r){if(B(r))return M();console.warn("[42 League] decline failed",r)}finally{x.delete(e.id),z()}}}async function Ue(e,t,n){x.add(e.id),I();try{await k.recordChallengeResult(e.id,t,n),F.delete(e.id)}catch(o){if(B(o))return M();console.warn("[42 League] record failed",o)}finally{x.delete(e.id),z()}}async function z(){try{const[e,t,n,o,a]=await Promise.all([k.me(),k.challenges(),k.pendingMatches(),k.playedMatches(),k.leaderboard()]);L=e.login,X=t,H=n.filter(i=>i.opponentLogin===L||i.declarerLogin===L),U=o,_=a;const r=await k.opsList().catch(()=>[]);me(_,U,r),I()}catch(e){if(B(e))return M();if(e instanceof de){X=[],H=[],U=[],_=[],document.getElementById(s)?.remove();return}console.warn("[42 League] refresh failed",e)}}function qe(){const e="league-42-sidebar-wrap",t="league-42-sidebar-link",n="league-42-sidebar-style";setInterval(()=>{if(document.getElementById(e))return;const o=document.querySelector(".main-left-navbar");if(!o)return;const a=o.querySelector(".main-left-menu")||o.querySelector("ul"),r=a||o,i=chrome.runtime.getURL("icons/baby-raccourci-logo-intra.png"),d=chrome.runtime.getURL("icons/baby-raccourci-logo-intra-hover.png");if(!document.getElementById(n)){const v=document.createElement("style");v.id=n,v.textContent=`
        #${e} {
          display: block;
          width: 100%;
          text-align: center;
          padding: 0;
          margin: 0;
        }
        #${t} {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 50px; /* Adapté à la taille native des boutons de l'intra */
          width: 100%;
          cursor: pointer;
          text-decoration: none;
          transition: background-color 0.2s;
        }
        #${t}:hover {
          background-color: rgba(255, 255, 255, 0.05);
        }
        #league-42-icon {
          width: 28px; /* Ajusté pour s'aligner parfaitement avec les icônes de l'intra */
          height: 28px;
          margin: 0 auto; 
          background-image: url('${i}');
          background-size: contain;
          background-repeat: no-repeat;
          background-position: center;
          transition: transform 0.1s ease, background-image 0.1s ease;
        }
        #${t}:hover #league-42-icon {
          background-image: url('${d}');
          transform: scale(1.1); 
        }
      `,document.head.appendChild(v)}const c=document.createElement("a");c.id=t,c.href=re,c.target="_blank",c.rel="noreferrer noopener",c.title="Aller sur 42 League";const m=document.createElement("div");m.id="league-42-icon",c.appendChild(m);const l=document.createElement("li");l.id=e,l.appendChild(c);const y=document.querySelector('a[href*="/shop"]')?.closest("li");y&&y.parentNode?y.parentNode.insertBefore(l,y.nextSibling):a?a.appendChild(l):r.appendChild(l)},1e3)}function He(){const e="league-42-user-stat",t="league-42-user-stats-style";if(!document.getElementById(t)){const n=document.createElement("style");n.id=t,n.textContent=`
      /* ── Aligner et uniformiser le padding de TOUTES les stats natives ── */
      .user-infos-sub .user-inline-stat:not(.hidden) {
        padding-top: 3px !important;
        padding-bottom: 3px !important;
        padding-left: 16px !important;
        padding-right: 16px !important;
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
        box-sizing: border-box !important;
      }
      /* ── Ajuster la hauteur du bloc pour s'aligner avec le bas du bloc level ── */
      .user-infos-sub {
        padding-bottom: 6px !important;
      }
      /* ── Nos stats injectées — même taille/padding que les natives ── */
      .${e} {
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
        width: 100% !important;
        padding: 3px 16px !important;
        margin: 0 !important;
        color: inherit !important;
        text-decoration: none !important;
        font-size: 13px !important;
        line-height: 1.4 !important;
        cursor: pointer;
        transition: background-color 120ms;
        box-sizing: border-box;
      }
      .${e}:hover { background-color: rgba(255, 255, 255, 0.045); }
      .${e}:first-of-type {
        border-top: 1px solid rgba(255, 255, 255, 0.08);
        margin-top: 3px !important;
        padding-top: 4px !important;
      }
      .${e} .l42-label {
        opacity: 0.82;
        font-weight: 400;
      }
      .${e} .l42-icon { opacity: 0.7; margin-right: 5px; font-size: 12px; }
      .${e} .l42-value {
        font-weight: 700;
        font-variant-numeric: tabular-nums;
      }
      .${e}[data-l42-stat="elo"]  .l42-value { color: #00d9dc; }
      .${e}[data-l42-stat="rank"] .l42-value { color: #ffb71b; }
      .${e} .l42-w { color: #ffb71b; }
      .${e} .l42-l { color: #ff3b5c; margin-left: 3px; }
      .${e} .l42-sep { opacity: 0.5; margin: 0 3px; font-weight: 400; }
    `,document.head.appendChild(n)}setInterval(()=>{const n=document.querySelector(".user-infos-sub");if(!n||!L)return;const a=location.pathname.match(/^\/users\/([a-z0-9_-]+)(?:\/|$)/i)?.[1]?.toLowerCase()??L,r=_.find(p=>p.login===a);if(!r)return;const i=U.filter(p=>p.playerALogin===a||p.playerBLogin===a),d=i.filter(p=>{const w=p.playerALogin===a;return w&&p.winner==="A"||!w&&p.winner==="B"}).length,c=i.length-d,m=`${r.elo}|${r.rank}|${d}|${c}`,l=n.querySelector(`.${e}`);if(l&&l.dataset.dataKey===m)return;n.querySelectorAll(`.${e}`).forEach(p=>p.remove());const u=`${re}/joueur/${encodeURIComponent(a)}`,y=a!==L,v=(p,w,N,E=!1)=>{const b=document.createElement("a");return b.className=e,b.dataset.l42Stat=p,b.href=u,b.target="_blank",b.rel="noreferrer noopener",b.title=y?`42 League — voir la fiche de ${a}`:"42 League — voir ma fiche",E&&(b.dataset.dataKey=m),b.innerHTML=`<span class="l42-label">${w}</span><span class="l42-value">${N}</span>`,b};n.append(v("elo",'<span class="l42-icon">⚔</span>42 League',String(r.elo),!0),v("rank","Rang",`#${r.rank}`),v("record","Bilan",`<span class="l42-w">${d}</span>W<span class="l42-sep">·</span><span class="l42-l">${c}</span>L`))},1e3)}async function Fe(){qe(),He(),new MutationObserver(()=>{const n=document.getElementById(s);(!n||!n.isConnected)&&I()}).observe(document.body,{childList:!0,subtree:!0}),(await pe.status().catch(()=>({authenticated:!1,login:null}))).authenticated&&(await z(),q=setInterval(z,$e))}Fe().catch(e=>console.error("[42 League] bootstrap failed",e));
//# sourceMappingURL=intra.ts-kVYf3lrC.js.map
