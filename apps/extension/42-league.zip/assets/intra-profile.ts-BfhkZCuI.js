import{a as x,A as $}from"./api-siOPKJBy.js";const i="league-42-profile-link",a="league-42-babyfoot-skill",b="league-42-profile-link-style",w="http://localhost:5173";function k(t){return`${w}/joueur/${encodeURIComponent(t)}`}function E(){if(document.getElementById(b))return;const t=document.createElement("style");t.id=b,t.textContent=`
    #${i} {
      display: inline-flex !important;
      align-items: center !important;
      gap: 6px !important;
      margin-left: 12px !important;
      padding: 6px 12px !important;
      background: #00babc !important;
      color: #ffffff !important;
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif !important;
      font-size: 12px !important;
      font-weight: 800 !important;
      letter-spacing: 0.1em !important;
      text-transform: uppercase !important;
      text-decoration: none !important;
      text-shadow: 0 1px 1px rgba(0, 0, 0, 0.35) !important;
      border-radius: 3px !important;
      border: 2px solid #ffffff !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25),
                  0 0 0 1px #00babc,
                  0 0 12px rgba(0, 186, 188, 0.5) !important;
      cursor: pointer !important;
      transition: filter 120ms, transform 80ms !important;
      vertical-align: middle !important;
      line-height: 1.1 !important;
    }
    #${i}:hover {
      filter: brightness(1.08) !important;
      transform: translateY(-1px) !important;
      background: #00d9dc !important;
    }
    #${i}::before {
      content: '⚔' !important;
      color: #ffffff !important;
      font-size: 13px !important;
      text-shadow: 0 1px 1px rgba(0, 0, 0, 0.35) !important;
    }
    #${i} .l42-elo {
      background: rgba(0, 0, 0, 0.28) !important;
      color: #ffffff !important;
      padding: 2px 7px !important;
      border-radius: 2px !important;
      font-variant-numeric: tabular-nums !important;
      font-weight: 700 !important;
    }
    #${a} {
      margin-top: 14px;
      padding-top: 12px;
      border-top: 1px dashed #ddd;
    }
    #${a} .l42-skill-row {
      display: flex; align-items: center; gap: 8px;
      margin-bottom: 4px;
    }
    #${a} .l42-skill-label {
      font-size: 12px; font-weight: 600; color: #00babc;
      letter-spacing: 0.04em; text-transform: uppercase;
    }
    #${a} .l42-skill-rank {
      font-size: 11px; color: #888;
      margin-left: auto;
      font-variant-numeric: tabular-nums;
    }
    #${a} .l42-skill-title {
      color: #c9a227; font-style: italic; font-weight: 600;
      font-size: 11px;
    }
  `,document.head.appendChild(t)}function v(){const t=location.pathname.match(/^\/users\/([a-z0-9_-]+)(?:\/|$)/i);return t&&t[1]?t[1].toLowerCase():null}function L(){const t=document.querySelector(".btn-group#title-selector .login[data-login]");return t?.parentElement?.parentElement?t.parentElement.parentElement:document.querySelector("h2.profile-name")}function C(t,e){if(document.getElementById(i))return;const n=L();if(!n)return;E();const r=document.createElement("a");r.id=i,r.href=k(t),r.target="_blank",r.rel="noreferrer noopener",r.title="42 League — voir le profil complet";const c=document.createElement("span");c.textContent="42 League";const o=document.createElement("span");o.className="l42-elo",o.textContent=`${e} ELO`,r.append(c,o),n.append(r)}function I(){const t=Array.from(document.querySelectorAll(".container-inner-item.boxed, .boxed"));for(const e of t){const n=e.querySelector(".profile-title");if(!n)continue;if((n.textContent??"").trim().toLowerCase().startsWith("skills"))return e}return null}function N(t){if(document.getElementById(a))return;const e=I();if(!e)return;E();const n=t.total>1?1-(t.rank-1)/(t.total-1):1,r=Math.max(0,Math.round(n*21)),c=Math.round(n*100),o=document.createElement("div");o.id=a;const m=document.createElement("div");m.className="l42-skill-row";const d=document.createElement("span");d.className="l42-skill-label",d.textContent="⚔ Babyfoot 42 League";const f=document.createElement("span");f.className="l42-skill-rank",f.textContent=`#${t.rank}/${t.total} · ${t.wins}W ${t.losses}L`,m.append(d,f),o.append(m);const l=document.createElement("a");l.className="progress-container",l.href=k(t.login),l.target="_blank",l.rel="noreferrer noopener";const u=document.createElement("div");u.className="progress double";const s=document.createElement("div");s.className="progress-bar",s.setAttribute("role","progressbar"),s.style.cssText=`width: ${c}%; background: linear-gradient(90deg, #00babc, #00d9dc); box-shadow: 0 0 8px rgba(0,217,220,0.4);`;const g=document.createElement("div");if(g.className="on-progress",g.textContent=`level ${r} - ${c}%`,u.append(s,g),l.append(u),o.append(l),t.title){const p=document.createElement("div");p.className="l42-skill-title",p.style.cssText="margin-top: 4px;",p.textContent=`« ${t.title} »`,o.append(p)}e.append(o)}async function y(){const t=v();if(t)try{const[e,n]=await Promise.all([x.userProfile(t),x.leaderboard()]);if(!e.user)return;C(t,e.user.elo),N({login:t,rank:e.rank??n.length,total:n.length,wins:e.wins,losses:e.losses,title:e.user.title})}catch(e){e instanceof $||console.warn("[42 League profile] bootstrap failed",e)}}y().catch(()=>{});let h=location.pathname;new MutationObserver(()=>{location.pathname!==h&&(h=location.pathname,document.getElementById(i)?.remove(),document.getElementById(a)?.remove(),y().catch(()=>{}))}).observe(document.body,{childList:!0,subtree:!0});
//# sourceMappingURL=intra-profile.ts-BfhkZCuI.js.map
