async function a(o){const t=await chrome.runtime.sendMessage({type:o});if(!t?.ok)throw new Error(t?.error??"background message failed");return t.data}const e={login:()=>a("auth:login"),logout:()=>a("auth:logout"),status:()=>a("auth:status")};export{e as a};
//# sourceMappingURL=auth-bridge-BJwpKOTo.js.map
